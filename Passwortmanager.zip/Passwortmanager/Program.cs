﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Passwort_Manager_IPT5._1
{
    internal class Program
    {
        static Dictionary<string, string> accounts = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            List<Passwörter> Passw_list = new List<Passwörter>();
            string Password = "";
            string PasswTitle = "";
            string PasswURL = "";
            string Passwgroup = "";
            byte[] modulus =
                {
            214,46,220,83,160,73,40,39,201,155,19,202,3,11,191,178,56,
            74,90,36,248,103,18,144,170,163,145,87,54,61,34,220,222,
            207,137,149,173,14,92,120,206,222,158,28,40,24,30,16,175,
            108,128,35,230,118,40,121,113,125,216,130,11,24,90,48,194,
            240,105,44,76,34,57,249,228,125,80,38,9,136,29,117,207,139,
            168,181,85,137,126,10,126,242,120,247,121,8,100,12,201,171,
            38,226,193,180,190,117,177,87,143,242,213,11,44,180,113,93,
            106,99,179,68,175,211,164,116,64,148,226,254,172,147
          };
            byte[] exponent = { 1, 0, 1 };

            Console.WriteLine("-------------------------------");
            Console.WriteLine("Password Manager - Anmeldung");
            Console.WriteLine("-------------------------------");
            //Login vom Passwortmanager
            bool loggedIn = false;
            string loggedInUser = "";
            while (!loggedIn)
            {
                Console.WriteLine("\nWählen Sie eine Option:");
                Console.WriteLine("1 - Konto hinzufügen");
                Console.WriteLine("2 - Einloggen");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.Clear();
                    Console.WriteLine("Konto hinzufügen");
                    Console.Write("Benutzername: ");
                    string username = Console.ReadLine();
                    Console.Write("Passwort: ");
                    string Logpassword = Console.ReadLine();
                    accounts[username] = Logpassword;
                    Console.WriteLine("Benutzer '{0}' wurde hinzugefügt.", username);
                    Console.ReadLine();
                    Console.Clear();
                }
                else if (input == "2")
                {
                    Console.Clear();
                    Console.WriteLine("Einloggen");
                    Console.Write("Benutzername: ");
                    string username = Console.ReadLine();
                    Console.Write("Passwort: ");
                    string Logpassword = Console.ReadLine();
                    if (accounts.TryGetValue(username, out string storedPassword) && Logpassword == storedPassword)
                    {
                        loggedIn = true;
                        loggedInUser = username;
                        Console.WriteLine("Herzlich willkommen, {0}!", loggedInUser);
                        Console.ReadLine();
                        Console.Clear();
                    }
                    else
                    {
                        Console.WriteLine("Falscher Benutzername oder Passwort, bitte erneut versuchen!");
                    }
                }
                else
                {
                    Console.WriteLine("Ungültige Auswahl.");
                }
            }

            Console.WriteLine("--------------------------------");
            Console.WriteLine("Was möchten Sie tun?");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Passwort hinzufügen[A]\n Passwort löschen[B]\n Passwörter anzeigen[C]\n Passwort generieren[D]\n Verschlüsseln/Entschlüsseln[E]");
            string eingabe = Console.ReadLine().ToUpper();
            //Passwort hinzufügen + speichert es in txt Datei 
            if (eingabe == "A")
            {
                Console.WriteLine("Geben Sie den Gruppennamen für den Passworteintrag ein:");
                Passwgroup = Console.ReadLine();
                Console.WriteLine("Geben sie einen Titel für den Passworteintrag ein:");
                PasswTitle = Console.ReadLine();
                Console.WriteLine("Geben sie das zuverwaltende Passwort ein:");
                Password = Console.ReadLine();
                Console.WriteLine("Geben sie die Passwort URL ein:");
                PasswURL = Console.ReadLine();
                Passw_list.Add(new Passwörter(PasswTitle, Password, PasswURL, Passwgroup));
                Console.WriteLine("Passwort {0} mit dem Titel {1} und der URL {2} wurde zur Gruppe {3} hinzugefügt", Password, PasswTitle, PasswURL, Passwgroup);
                string filePath = "Passwörter.txt";
                try
                {
                    using (StreamWriter sw = File.AppendText(filePath))
                    {
                        sw.WriteLine("Gruppe: " + Passwgroup + ", " + "Titel: " + PasswTitle + ", " + "Passwort: " + Password + ", " + "URL: " + PasswURL);
                        Console.WriteLine("Passwort wurde erfolgreich gespeichert.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ein Fehler ist aufgetreten: {ex.Message}");
                }


            }
            //Passwort löschen mit der URL
            else if (eingabe == "B")
            {
                Console.Clear();
                Console.WriteLine("Welches Passwort wollen Sie entfernen? [Geben Sie bitte die URL ein]:  ");
                string urlToRemove = Console.ReadLine();
                string filePath = "Passwörter.txt";
                try
                {
                    List<string> lines = File.ReadAllLines(filePath).ToList();
                    bool found = false;
                    for (int i = 0; i < lines.Count; i++)
                    {
                        if (lines[i].Contains("URL: " + urlToRemove))
                        {
                            lines.RemoveAt(i);
                            found = true;
                            break;
                        }
                    }
                    if (found)
                    {
                        File.WriteAllLines(filePath, lines);
                        Console.WriteLine("Passwort mit der URL {0} wurde gelöscht.", urlToRemove);
                    }
                    else
                    {
                        Console.WriteLine("Passwort mit der URL {0} wurde nicht gefunden.", urlToRemove);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ein Fehler ist aufgetreten: {ex.Message}");
                }

            }
            //Passwörter anzeigen
            else if (eingabe == "C")
            {
                Console.WriteLine("Geben Sie den Gruppennamen ein, dessen Passwörter Sie anzeigen möchten:");
                string groupToDisplay = Console.ReadLine();
                string filePath = "Passwörter.txt";
                try
                {
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);

                        if (parts.Length == 4)
                        {
                            string group = parts[0].Substring("Gruppe: ".Length);
                            string title = parts[1].Substring("Titel: ".Length);
                            string password = parts[2].Substring("Passwort: ".Length);
                            string url = parts[3].Substring("URL: ".Length);

                            if (group == groupToDisplay)
                            {
                                Console.WriteLine("Gruppe: {0}\nTitel: {1}\nPasswort: {2}\nURL: {3}\n", group, title, password, url);
                            }
                        }
                    }

                    Console.ReadKey();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ein Fehler ist aufgetreten: {ex.Message}");
                }

            }
            //zufälliges Passwort generieren 
            else if (eingabe == "D")
            {
                int passwordLength = 14; // Die gewünschte Passwortlänge
                string password = GenerateRandomPassword(passwordLength);
                Console.WriteLine("Generiertes Passwort: {0} ", GenerateRandomPassword(passwordLength));
            }
            //Passwort verschlüsseln und entschlüsseln 
            else if (eingabe == "E")
            {
                using (RSA rsa = RSA.Create())
                {
                    // Create a new instance of the RSAParameters structure.
                    RSAParameters rsaKeyInfo = new RSAParameters();
                    // Set rsaKeyInfo to the public key values.
                    rsaKeyInfo.Modulus = modulus;
                    rsaKeyInfo.Exponent = exponent;
                    // Import key parameters into rsa.
                    rsa.ImportParameters(rsaKeyInfo);
                    // Create a new instance of the default Aes implementation class.
                    using (Aes aes = Aes.Create())
                    {
                        // Encrypt the symmetric key and IV.
                        byte[] encryptedSymmetricKey = rsa.Encrypt(aes.Key, RSAEncryptionPadding.Pkcs1);
                        byte[] encryptedSymmetricIV = rsa.Encrypt(aes.IV, RSAEncryptionPadding.Pkcs1);
                        while (true)
                        {
                            Console.Clear();
                            Console.WriteLine("Wählen Sie eine Option:\n");
                            Console.WriteLine("1. Passwort verschlüsseln");
                            Console.WriteLine("2. Passwort entschlüsseln");
                            Console.WriteLine("3. Beenden\n");
                            Console.Write("Geben Sie Ihre Wahl ein: ");
                            string choice = Console.ReadLine();
                            switch (choice)
                            {
                                case "1":
                                    Console.Clear();
                                    Console.Write("Geben Sie das zu verschlüsselnde Passwort ein: ");
                                    string dataToEncrypt = Console.ReadLine();
                                    byte[] encryptedData = EncryptData(dataToEncrypt, aes);
                                    Console.WriteLine("Verschlüsseltes Passwort: " + Convert.ToBase64String(encryptedData));
                                    Console.ReadLine();
                                    break;
                                case "2":
                                    Console.Clear();
                                    Console.Write("Geben Sie das zu entschlüsselnden Passwort ein: ");
                                    string base64EncryptedData = Console.ReadLine();
                                    byte[] encryptedBytes = Convert.FromBase64String(base64EncryptedData);
                                    string decryptedData = DecryptData(encryptedBytes, aes);
                                    Console.WriteLine("Entschlüsselte Passwort: " + decryptedData);
                                    Console.ReadLine();
                                    break;
                                case "3":
                                    Environment.Exit(0);
                                    break;
                                default:
                                    Console.Clear();
                                    Console.WriteLine("Ungültige Auswahl. Bitte versuchen Sie es erneut.");
                                    Console.ReadLine();
                                    break;
                            }
                        }
                    }
                }

            }

            Console.ReadKey();
        }
        //gebrauchte Methoden für das generieren, entschlüsseln und  verschlüsseln
        static string GenerateRandomPassword(int length)
        {
            const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()-_=+";

            Random random = new Random();
            StringBuilder password = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                int index = random.Next(validChars.Length);
                password.Append(validChars[index]);
            }
            return password.ToString();
        }

        static byte[] EncryptData(string data, Aes aes)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(dataBytes, 0, dataBytes.Length);
                    cs.FlushFinalBlock();
                }
                return ms.ToArray();
            }
        }
        static string DecryptData(byte[] encryptedData, Aes aes)
        {
            using (MemoryStream ms = new MemoryStream(encryptedData))
            {
                using (CryptoStream cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                {
                    using (StreamReader reader = new StreamReader(cs))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }
        }
    }
}
