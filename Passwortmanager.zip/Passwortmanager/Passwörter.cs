﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Passwort_Manager_IPT5._1
{
    internal class Passwörter
    {
        public string _passtitle = "";
        public string _password = "";
        public string _passwURL = "";
        public string _passwgroup = "";
        public Passwörter(string Passtitle, string Password, string URl, string Group)
        {
            this._passtitle = Passtitle;
            this._password = Password;
            this._passwURL = URl;
            this._passwgroup = Group;
        }
        public string Passtitle
        {
            get { return _passtitle; }
            set { _passtitle = value; }
        }
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        public string URL
        {
            get { return _passwURL; }
            set { _passwURL = value; }
        }
        public string Group
        {
            get { return _passwgroup; }
            set { _passwgroup = value; }
        }
    }
}